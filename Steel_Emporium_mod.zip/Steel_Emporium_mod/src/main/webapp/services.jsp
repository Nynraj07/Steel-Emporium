<%@ include file="component/header.jsp" %>

	<!-- Start Hero Section -->
	<div class="hero">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-5">
					<div class="intro-excerpt">
						<h1>Services</h1>
						<p class="mb-4">Discover Precision Craftsmanship: Our services encompass precision steel
							fabrication tailored to your exact specifications.</p>
						<p><a href="/login" class="btn btn-secondary me-2">Shop Now</a>
					</div>
				</div>
				<div class="col-lg-7">
					<div class="hero-img-wrap">
						<img src="images/couch.png" class="img-fluid">
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Hero Section -->



	<!-- Start Why Choose Us Section -->
	<div class="why-choose-section">
		<div class="container">


			<div class="row my-5">
				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/truck.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>Fast &amp; Free Shipping</h3>
						<p>Do not sit and relax, it is free shipping time.</p>
					</div>
				</div>

				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/bag.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>Easy to Shop</h3>
						<p>Shopping just got a whole lot easier with our app.</p>
					</div>
				</div>

				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/support.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>24/7 Support</h3>
						<p>Please let me know if I can assist you in any way
							We are there for you. Here for you 24/7.</p>
					</div>
				</div>

				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/return.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>Hassle Free Returns</h3>
						<p>Making Your Shopping Experience Stress-Free
							Seamless Returns: Hassle-Free Solutions for Your Peace of Mind.</p>
					</div>
				</div>

				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">


					</div>

				</div>
			</div>
			<!-- End Why Choose Us Section -->

			<!-- Start Product Section -->
			<div class="product-section pt-0">
				<div class="container">
					<div class="row">

						<!-- Start Column 1 -->
						<div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
							<h2 class="mb-4 section-title">Crafted with excellent material.</h2>
							<p class="mb-4">Crafted with precision and premium materials, our products redefine
								excellence. </p>
							<p><a href="#" class="btn">Explore</a></p>
						</div>
						<!-- End Column 1 -->

						<!-- Start Column 2 -->
						<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
							<a class="product-item" href="#">
								<img src="images/product-1.png" class="img-fluid product-thumbnail">
								<h3 class="product-title">Nordic Chair</h3>
								<strong class="product-price"><span>&#8377;</span>5000.00</strong>

								<span class="icon-cross">
									<img src="images/cross.svg" class="img-fluid">
								</span>
							</a>
						</div>
						<!-- End Column 2 -->

						<!-- Start Column 3 -->
						<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
							<a class="product-item" href="#">
								<img src="images/product-2.png" class="img-fluid product-thumbnail">
								<h3 class="product-title">Kruzo Aero Chair</h3>
								<strong class="product-price"><span>&#8377;</span>7800.00</strong>

								<span class="icon-cross">
									<img src="images/cross.svg" class="img-fluid">
								</span>
							</a>
						</div>
						<!-- End Column 3 -->

						<!-- Start Column 4 -->
						<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
							<a class="product-item" href="#">
								<img src="images/product-3.png" class="img-fluid product-thumbnail">
								<h3 class="product-title">Ergonomic Chair</h3>
								<strong class="product-price"><span>&#8377;</span>4300.00</strong>

								<span class="icon-cross">
									<img src="images/cross.svg" class="img-fluid">
								</span>
							</a>
						</div>
						<!-- End Column 4 -->

					</div>
				</div>
			</div>
			<!-- End Product Section -->





				<!-- Start Footer Section -->
				<%@ include file="component/footer.jsp" %>
					<!-- End Footer Section -->


					<script src="js/bootstrap.bundle.min.js"></script>
					<script src="js/tiny-slider.js"></script>
					<script src="js/custom.js"></script>
					</body>

					</html>