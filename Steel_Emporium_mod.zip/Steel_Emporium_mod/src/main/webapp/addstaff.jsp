<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Staff - Steel Emporium</title>
    <style>
        body{font-family:Arial,sans-serif;margin:0;min-height:100vh;display:flex;justify-content:center;align-items:center;background:#f3f6f9}
        .container{background:#fff;padding:30px;border-radius:12px;box-shadow:0 8px 25px rgba(0,0,0,.12);width:400px}
        h2{text-align:center;color:#2c3e50;margin-bottom:24px}
        label{font-weight:600;display:block;margin:12px 0 6px}
        input{width:100%;box-sizing:border-box;padding:11px;border:1px solid #ccc;border-radius:6px}
        button{width:100%;margin-top:20px;padding:11px;border:0;border-radius:6px;background:#2c3e50;color:#fff;cursor:pointer}
        a{display:block;text-align:center;margin-top:15px;color:#2c3e50;text-decoration:none}
    </style>
</head>
<body>
<div class="container">
    <h2>Add Staff</h2>
    <form action="/signup" method="post">
        <label for="name">Name</label>
        <input id="name" name="name" type="text" required minlength="3">
        <label for="user_id">Email ID</label>
        <input id="user_id" name="user_id" type="email" required>
        <label for="password">Password</label>
        <input id="password" name="password" type="password" required minlength="6">
        <input type="hidden" name="role" value="staff">
        <button type="submit">Create Staff Account</button>
    </form>
    <a href="/viewstaff">Back to Staff</a>
</div>
</body>
</html>
