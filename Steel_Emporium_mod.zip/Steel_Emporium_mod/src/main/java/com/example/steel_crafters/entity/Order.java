package com.example.steel_crafters.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.*;

@Entity
@Table(name="save_order")
public class Order {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="order_id") private Integer orderId;
    @Column(name="user_id",nullable=false,length=50) private String userId;
    @Column(nullable=false) private Integer price;
    @Column(name="order_status",nullable=false) private Integer orderStatus=1;
    @Column(nullable=false,length=200) private String products;
    @Column(name="productsname",nullable=false,length=500) private String productsName;
    @Column(nullable=false,length=11) private String status="pending";
    @Column(name="delivery_status",nullable=false,length=40) private String deliveryStatus="Not Delivered";
    @Column(name="created_at") private LocalDateTime createdAt=LocalDateTime.now();
    @Column(name="bill_path") private String billPath;

    @Transient private List<OrderItem> items=new ArrayList<>();

    public Integer getOrder_id(){return orderId;} public Integer getOrderId(){return orderId;} public void setOrderId(Integer v){orderId=v;}
    public String getUser_id(){return userId;} public String getUserId(){return userId;} public void setUserId(String v){userId=v;}
    public Integer getPrice(){return price;} public void setPrice(Integer v){price=v;}
    public Integer getOrder_status(){return orderStatus;} public Integer getOrderStatus(){return orderStatus;} public void setOrderStatus(Integer v){orderStatus=v;}
    public String getProducts(){return products;} public void setProducts(String v){products=v;}
    public String getProductsname(){return productsName;} public String getProductsName(){return productsName;} public void setProductsName(String v){productsName=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getDelivery_status(){return deliveryStatus;} public String getDeliveryStatus(){return deliveryStatus;} public void setDeliveryStatus(String v){deliveryStatus=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
    public String getBillPath(){return billPath;} public void setBillPath(String v){billPath=v;}
    public List<OrderItem> getItems(){return items;} public void setItems(List<OrderItem> v){items=v;}
}
