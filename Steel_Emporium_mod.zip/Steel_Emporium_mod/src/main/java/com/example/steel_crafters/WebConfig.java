package com.example.steel_crafters;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String uploadPath="file:"+System.getProperty("user.dir")+"/uploads/";
        String billPath="file:"+System.getProperty("user.dir")+"/bills/";
        registry.addResourceHandler("/uploads/**").addResourceLocations(uploadPath);
        registry.addResourceHandler("/bills/**").addResourceLocations(billPath);
    }
}
