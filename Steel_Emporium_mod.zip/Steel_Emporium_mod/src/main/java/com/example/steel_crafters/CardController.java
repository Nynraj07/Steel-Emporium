package com.example.steel_crafters;

import com.example.steel_crafters.entity.Card;
import com.example.steel_crafters.repository.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class CardController {
    @Autowired private CardRepository cardRepository;

    @GetMapping("/card") public String showCardPage(){return "card";}

    @PostMapping("/saveCard")
    public String saveCard(@RequestParam("accountNumber") String accountNumber,@RequestParam("cvv") String cvv,
                           @RequestParam("expiryDate") String expiryDate,@RequestParam("amount") double amount,
                           org.springframework.ui.Model model){
        Card card=cardRepository.findByAccountNumberAndCvvAndExpiryDate(accountNumber,cvv,expiryDate).orElseGet(Card::new);
        card.setAccountNumber(accountNumber);card.setCvv(cvv);card.setExpiryDate(expiryDate);card.setAmount(amount);cardRepository.save(card);
        model.addAttribute("message","Card details saved successfully!");return "card";
    }

    @PostMapping("/saveCardAndProceed")
    @ResponseBody
    public String saveCardAndProceed(@RequestParam("accountNumber") String accountNumber,@RequestParam("cvv") String cvv,
                                     @RequestParam("expiryDate") String expiryDate,@RequestParam("amount") double amount){
        try{
            var op=cardRepository.findByAccountNumberAndCvvAndExpiryDate(accountNumber,cvv,expiryDate);
            if(op.isEmpty())return "Invalid card details!";
            Card card=op.get();if(card.getAmount()<amount)return "Insufficient balance!";
            card.setAmount(card.getAmount()-amount);cardRepository.save(card);return "PAID";
        }catch(Exception e){e.printStackTrace();return "Error during payment!";}
    }
}
