package com.example.steel_crafters.entity;

import jakarta.persistence.*;

@Entity
@Table(name="order_item")
public class OrderItem {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(name="order_id",nullable=false) private Integer orderId;
    @Column(name="product_id",nullable=false) private Integer productId;
    private String productName;
    @Column(length=800) private String description;
    private Integer rate;
    private Integer quantity;
    private Integer subtotal;
    @Lob @Column(columnDefinition="LONGBLOB") private byte[] productImage;

    public OrderItem(){}
    public OrderItem(Integer orderId,Integer productId,String name,String description,Integer rate,Integer qty,byte[] image){
        this.orderId=orderId;this.productId=productId;this.productName=name;this.description=description;this.rate=rate;this.quantity=qty;this.subtotal=rate*qty;this.productImage=image;
    }
    public Long getId(){return id;} public Integer getOrderId(){return orderId;} public void setOrderId(Integer v){orderId=v;}
    public Integer getProductId(){return productId;} public String getProductName(){return productName;} public String getDescription(){return description;}
    public Integer getRate(){return rate;} public Integer getQuantity(){return quantity;} public Integer getSubtotal(){return subtotal;}
    public byte[] getProductImage(){return productImage;}
}
