package com.example.steel_crafters.repository;
import com.example.steel_crafters.entity.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public interface CardRepository extends JpaRepository<Card,Integer>{
    Optional<Card> findByAccountNumberAndCvvAndExpiryDate(String accountNumber,String cvv,String expiryDate);
}
