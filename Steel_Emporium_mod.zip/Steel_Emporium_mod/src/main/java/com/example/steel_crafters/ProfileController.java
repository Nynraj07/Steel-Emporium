package com.example.steel_crafters;

import com.example.steel_crafters.entity.UserProfile;
import com.example.steel_crafters.repository.UserProfileRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;

@Controller
public class ProfileController {
    @Autowired private UserProfileRepository profileRepository;
    private static final String UPLOAD_DIR=System.getProperty("user.dir")+"/uploads/";

    @GetMapping("/profile")
    public String viewProfile(HttpSession session,Model model){
        String userId=(String)session.getAttribute("user_id");if(userId==null)return "redirect:/login";
        model.addAttribute("profile",profileRepository.findByUserId(userId).orElse(null));return "profile";
    }

    @PostMapping("/updateProfile")
    public String updateProfile(@RequestParam("address") String address,@RequestParam("age") int age,
                                @RequestParam("phone") String phone,@RequestParam("gender") String gender,
                                @RequestParam("city") String city,@RequestParam("state") String state,
                                @RequestParam("country") String country,@RequestParam(value="photo",required=false) MultipartFile photo,
                                HttpSession session)throws IOException{
        String userId=(String)session.getAttribute("user_id");if(userId==null)return "redirect:/login";
        UserProfile p=profileRepository.findByUserId(userId).orElseGet(UserProfile::new);p.setUserId(userId);
        p.setAddress(address);p.setAge(age);p.setPhone(phone);p.setGender(gender);p.setCity(city);p.setState(state);p.setCountry(country);
        if(photo!=null&&!photo.isEmpty()){
            File dir=new File(UPLOAD_DIR);if(!dir.exists())dir.mkdirs();
            String fileName=System.currentTimeMillis()+"_"+photo.getOriginalFilename();photo.transferTo(new File(dir,fileName));p.setPhoto("/uploads/"+fileName);
        }
        profileRepository.save(p);return "redirect:/profile";
    }
}
