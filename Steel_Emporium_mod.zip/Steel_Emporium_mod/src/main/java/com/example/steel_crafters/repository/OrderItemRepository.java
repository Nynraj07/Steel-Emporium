package com.example.steel_crafters.repository;
import com.example.steel_crafters.entity.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public interface OrderItemRepository extends JpaRepository<OrderItem,Long>{
    List<OrderItem> findByOrderId(Integer orderId);
}
