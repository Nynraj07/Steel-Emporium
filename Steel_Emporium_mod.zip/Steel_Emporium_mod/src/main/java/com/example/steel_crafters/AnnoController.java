package com.example.steel_crafters;

import com.example.steel_crafters.entity.*;
import com.example.steel_crafters.repository.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.*;

@Controller
public class AnnoController {
    @Autowired private UserRepository userRepository;
    @Autowired private ProductRepository productRepository;
    @Autowired private CartRepository cartRepository;
    @Autowired private OrderRepository orderRepository;
    @Autowired private OrderItemRepository orderItemRepository;
    @Autowired private FaqRepository faqRepository;

    @PostMapping("/login")
    public String loginCheck(@RequestParam("user_id") String userId,
                             @RequestParam("password") String password,
                             Model model, HttpSession session) {
        Optional<User> found = userRepository.findByUserIdAndPassword(userId.trim(), password);
        if (found.isEmpty()) {
            model.addAttribute("sms", "Invalid Details");
            return "login";
        }
        User user = found.get();
        if (!Objects.equals(user.getStatus(), 1)) {
            model.addAttribute("sms", "Please contact admin");
            return "login";
        }
        session.setAttribute("name", user.getName());
        session.setAttribute("user_id", user.getUserId());
        session.setAttribute("role", user.getRole());
        if ("admin".equalsIgnoreCase(user.getRole())) return "redirect:/admindashboard?loginSuccess=1";
        if ("customer".equalsIgnoreCase(user.getRole())) return "redirect:/shop?loginSuccess=1";
        if ("staff".equalsIgnoreCase(user.getRole())) return "redirect:/shop?loginSuccess=1";
        model.addAttribute("sms", "Some error occurred...");
        return "login";
    }

    @GetMapping("/login") public String login(){ return "login"; }
    @GetMapping("/signup") public String signup(){ return "signup"; }

    @PostMapping("/signup")
    public String signupSave(Model model, @RequestParam("name") String name,
                             @RequestParam("password") String password,
                             @RequestParam("user_id") String userId,
                             @RequestParam("role") String role) {
        if (userRepository.existsById(userId.trim())) {
            model.addAttribute("sms", "Email/User ID already registered.");
            model.addAttribute("popupType", "error");
            return "signup";
        }
        User user = new User(userId.trim(), name.trim(), password, role);
        userRepository.save(user);
        model.addAttribute("sms", "Successfully Registered");
        model.addAttribute("popupType", "success");
        return "signup";
    }

    @GetMapping("/products")
    public String products(Model model){ model.addAttribute("products", productRepository.findAll()); return "products"; }
    @GetMapping("/faq")
    public String faq(Model model){ model.addAttribute("faq", faqRepository.findAll()); return "faq"; }

    @PostMapping("/addtocart")
    public String addToCart(@RequestParam("prodid") Integer prodid,
                            @RequestParam("prodname") String prodname,
                            @RequestParam(value="prodrate",required=false) Integer ignoredRate,
                            HttpSession session, RedirectAttributes ra) {
        String userId=(String)session.getAttribute("user_id");
        if(userId==null) return "redirect:/login";
        Product product=productRepository.findById(prodid).orElse(null);
        if(product==null || product.getProdqty()<=0){ ra.addFlashAttribute("errorMessage","Product is out of stock."); return "redirect:/shop"; }
        Optional<Cart> existing=cartRepository.findByUserId(userId).stream().filter(c->c.getProdid().equals(prodid)).findFirst();
        if(existing.isPresent()){
            Cart c=existing.get();
            if(c.getQty()>=product.getProdqty()){ra.addFlashAttribute("errorMessage","Available stock: "+product.getProdqty());}
            else {c.setQty(c.getQty()+1);cartRepository.save(c);}
        }else{
            Cart c=new Cart(); c.setUserId(userId); c.setProdid(prodid); c.setProdname(product.getProdname()); c.setQty(1); cartRepository.save(c);
        }
        return "redirect:/shop";
    }

    private List<Cart> enrichedCart(String userId){
        List<Cart> carts=cartRepository.findByUserId(userId);
        for(Cart c:carts) c.setProduct(productRepository.findById(c.getProdid()).orElse(null));
        return carts;
    }

    @GetMapping("/cart")
    public String cart(Model model,HttpSession session){
        String userId=(String)session.getAttribute("user_id"); if(userId==null)return "redirect:/login";
        model.addAttribute("product",enrichedCart(userId)); return "cart";
    }

    @PostMapping("/removefromcart")
    public String removeFromCart(@RequestParam("sl_no") Integer slNo,HttpSession session){
        String userId=(String)session.getAttribute("user_id");
        if(userId!=null) cartRepository.findBySlNoAndUserId(slNo,userId).ifPresent(cartRepository::delete);
        return "redirect:/cart";
    }

    @PostMapping("/addone")
    public String addOne(@RequestParam("sl_no") Integer slNo,HttpSession session,RedirectAttributes ra){
        String userId=(String)session.getAttribute("user_id"); if(userId==null)return "redirect:/login";
        Optional<Cart> op=cartRepository.findBySlNoAndUserId(slNo,userId); if(op.isEmpty())return "redirect:/cart";
        Cart c=op.get(); Product p=productRepository.findById(c.getProdid()).orElse(null);
        if(p==null)return "redirect:/cart";
        if(c.getQty()>=p.getProdqty()) ra.addFlashAttribute("errorMessage","Only "+p.getProdqty()+" available.");
        else {c.setQty(c.getQty()+1);cartRepository.save(c);}
        return "redirect:/cart";
    }

    @PostMapping("/removeone")
    public String removeOne(@RequestParam("sl_no") Integer slNo,HttpSession session,RedirectAttributes ra){
        String userId=(String)session.getAttribute("user_id"); if(userId==null)return "redirect:/login";
        Optional<Cart> op=cartRepository.findBySlNoAndUserId(slNo,userId); if(op.isEmpty())return "redirect:/cart";
        Cart c=op.get();
        if(c.getQty()<=1)ra.addFlashAttribute("errorMessage","Quantity cannot be less than 1.");
        else {c.setQty(c.getQty()-1);cartRepository.save(c);}
        return "redirect:/cart";
    }

    @GetMapping("/checkout")
    public String checkout(Model model,HttpSession session){
        String userId=(String)session.getAttribute("user_id"); if(userId==null)return "redirect:/login";
        List<Cart> carts=enrichedCart(userId); model.addAttribute("product",carts);
        int total=carts.stream().mapToInt(c->c.getQty()*c.getProdrate()).sum();
        Map<String,Object> totalMap=new HashMap<>(); totalMap.put("total_sum",total); model.addAttribute("total",List.of(totalMap));
        return "checkout";
    }

    @GetMapping("/shopnow") public String shopnow(){return "redirect:/login";}

    @PostMapping("/saveorder")
    public String saveOrder(@RequestParam(value="total",required=false) String ignoredTotal,
                            @RequestParam(value="user_id",required=false) String ignoredUser,
                            @RequestParam(value="products",required=false) String ignoredProducts,
                            @RequestParam(value="productsname",required=false) String ignoredNames,
                            HttpSession session, Model model){
        String userId=(String)session.getAttribute("user_id"); if(userId==null)return "redirect:/login";
        List<Cart> carts=enrichedCart(userId);
        if(carts.isEmpty()){model.addAttribute("sms","Cart is empty.");return "thankyou";}
        int total=0;
        StringJoiner ids=new StringJoiner(","), names=new StringJoiner(",");
        for(Cart c:carts){
            Product p=c.getProduct();
            if(p==null || c.getQty()>p.getProdqty()){model.addAttribute("sms","Insufficient stock for "+c.getProdname());return "thankyou";}
            total += c.getQty()*p.getProdrate(); ids.add(String.valueOf(p.getProdid())); names.add(p.getProdname());
        }
        Order order=new Order(); order.setUserId(userId); order.setPrice(total); order.setProducts(ids.toString()); order.setProductsName(names.toString());
        order.setStatus("pending"); order.setDeliveryStatus("Not Delivered");
        order=orderRepository.save(order);
        for(Cart c:carts){
            Product p=c.getProduct();
            OrderItem item=new OrderItem(order.getOrderId(),p.getProdid(),p.getProdname(),p.getDescription(),p.getProdrate(),c.getQty(),p.getProd_img());
            orderItemRepository.save(item);
            p.setProdqty(p.getProdqty()-c.getQty()); productRepository.save(p);
        }
        cartRepository.deleteByUserId(userId);
        return "thankyou";
    }

    @GetMapping("/myorder")
    public String myorder(Model model,HttpSession session){
        String userId=(String)session.getAttribute("user_id"); if(userId==null)return "redirect:/login";
        model.addAttribute("orders",orderRepository.findByUserIdOrderByOrderIdDesc(userId)); return "myorder";
    }

    @PostMapping("/ordercancel")
    public String orderCancel(@RequestParam("order_id") Integer orderId,HttpSession session){
        String userId=(String)session.getAttribute("user_id");
        if(userId!=null) orderRepository.findById(orderId).filter(o->userId.equals(o.getUserId())).ifPresent(o->{o.setStatus("Cancelled");orderRepository.save(o);});
        return "redirect:/myorder";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session){session.invalidate();return "redirect:/login";}
    @GetMapping("/") public String home(){return "redirect:/index";}
    @GetMapping("/blog") public String blog(){return "blog";}
    @GetMapping("/addstaff") public String addStaff(){return "addstaff";}
    @GetMapping("/about") public String about(){return "about";}
    @GetMapping("/services") public String services(){return "services";}
    @GetMapping("/index") public String index(){return "index";}
}
