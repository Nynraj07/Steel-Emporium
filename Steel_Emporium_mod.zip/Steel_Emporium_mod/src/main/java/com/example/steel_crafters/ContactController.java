package com.example.steel_crafters;

import com.example.steel_crafters.entity.Contact;
import com.example.steel_crafters.repository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ContactController {
    @Autowired private ContactRepository contactRepository;
    @PostMapping("/save_contact")
    public String contactus(Model model,@RequestParam("fname") String fname,@RequestParam("lname") String lname,
                             @RequestParam("email") String email,@RequestParam("msg") String msg){
        Contact c=new Contact();c.setFname(fname);c.setLname(lname);c.setEmail(email);c.setMsg(msg);contactRepository.save(c);
        return "redirect:/contact?success=1";
    }
    @GetMapping("/contact") public String contact(){return "contact";}
}
