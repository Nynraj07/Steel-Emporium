package com.example.steel_crafters.entity;

import jakarta.persistence.*;

@Entity
@Table(name="contact")
public class Contact {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="sl_no") private Integer slNo;
    private String fname,lname,email;
    @Column(length=400) private String msg;
    public Integer getSl_no(){return slNo;} public Integer getSlNo(){return slNo;}
    public String getFname(){return fname;} public void setFname(String v){fname=v;}
    public String getLname(){return lname;} public void setLname(String v){lname=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getMsg(){return msg;} public void setMsg(String v){msg=v;}
    public String getUser_id(){return email;}
}
