package com.example.steel_crafters.repository;
import com.example.steel_crafters.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public interface UserRepository extends JpaRepository<User,String>{
    Optional<User> findByUserIdAndPassword(String userId,String password);
    List<User> findByRole(String role);
}
