package com.example.steel_crafters.entity;

import jakarta.persistence.*;
import java.util.Base64;

@Entity
@Table(name="product_master")
public class Product {
    @Id
    @Column(name="prodid")
    private Integer prodid;
    @Column(nullable=false,length=50) private String prodname;
    @Column(nullable=false,length=800) private String description;
    @Column(nullable=false) private Integer prodrate;
    @Column(nullable=false) private Integer prodqty;
    @Lob
    @Column(name="prod_img", columnDefinition="LONGBLOB")
    private byte[] prodImg;

    public Product(){}
    public Integer getProdid(){return prodid;} public void setProdid(Integer v){prodid=v;}
    public String getProdname(){return prodname;} public void setProdname(String v){prodname=v;}
    public String getDescription(){return description;} public void setDescription(String v){description=v;}
    public Integer getProdrate(){return prodrate;} public void setProdrate(Integer v){prodrate=v;}
    public Integer getProdqty(){return prodqty;} public void setProdqty(Integer v){prodqty=v;}
    public byte[] getProd_img(){return prodImg;} public void setProd_img(byte[] v){prodImg=v;}
    public byte[] getProdImg(){return prodImg;} public void setProdImg(byte[] v){prodImg=v;}
    public String getImageBase64(){return prodImg == null ? "" : Base64.getEncoder().encodeToString(prodImg);}
}
