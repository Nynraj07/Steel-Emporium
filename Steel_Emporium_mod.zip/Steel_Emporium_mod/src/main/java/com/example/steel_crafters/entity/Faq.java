package com.example.steel_crafters.entity;

import jakarta.persistence.*;

@Entity
@Table(name="faq")
public class Faq {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="sl_no") private Integer slNo;
    @Column(nullable=false,length=500) private String question;
    @Column(nullable=false,length=1000) private String answer;
    public Faq(){}
    public Faq(String q,String a){question=q;answer=a;}
    public Integer getSl_no(){return slNo;} public void setSl_no(Integer v){slNo=v;}
    public Integer getSlNo(){return slNo;} public void setSlNo(Integer v){slNo=v;}
    public String getQuestion(){return question;} public void setQuestion(String v){question=v;}
    public String getAnswer(){return answer;} public void setAnswer(String v){answer=v;}
}
