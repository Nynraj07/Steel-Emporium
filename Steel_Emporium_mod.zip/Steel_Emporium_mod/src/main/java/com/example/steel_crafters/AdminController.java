package com.example.steel_crafters;

import com.example.steel_crafters.entity.*;
import com.example.steel_crafters.repository.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;

@Controller
public class AdminController {
    @Autowired private JavaMailSender mailSender;
    @Autowired private UserRepository userRepository;
    @Autowired private ProductRepository productRepository;
    @Autowired private OrderRepository orderRepository;
    @Autowired private OrderItemRepository orderItemRepository;
    @Autowired private FaqRepository faqRepository;
    @Autowired private ContactRepository contactRepository;

    @GetMapping("/admindashboard")
    public String dashboard(Model model){
        model.addAttribute("totalUsers",userRepository.count());
        model.addAttribute("totalProducts",productRepository.count());
        model.addAttribute("totalOrders",orderRepository.count());
        model.addAttribute("approvedCount",orderRepository.countByStatus("Approved"));
        model.addAttribute("rejectedCount",orderRepository.findAll().stream().filter(o -> "Rejected".equalsIgnoreCase(o.getStatus()) || "Cancelled".equalsIgnoreCase(o.getStatus())).count());

        List<Map<String,Object>> deliveryStats=new ArrayList<>();
        for(String status:List.of("pending","not deliver","On the Way","Delivered")){
            long count=orderRepository.countByDeliveryStatus(status);
            if(count>0){Map<String,Object> m=new HashMap<>();m.put("delivery_status",status);m.put("count",count);deliveryStats.add(m);}
        }
        model.addAttribute("deliveryStats",deliveryStats);
        model.addAttribute("recentOrders",orderRepository.findTop5ByOrderByOrderIdDesc());

        Map<String,Long> counts=new HashMap<>();
        for(Order o:orderRepository.findAll()) counts.merge(o.getUserId(),1L,Long::sum);
        List<Map<String,Object>> buyers=new ArrayList<>();
        counts.entrySet().stream().sorted(Map.Entry.<String,Long>comparingByValue().reversed()).limit(5).forEach(e->{
            Map<String,Object> m=new HashMap<>();m.put("username",userRepository.findById(e.getKey()).map(User::getName).orElse(e.getKey()));m.put("order_count",e.getValue());buyers.add(m);
        });
        model.addAttribute("userPurchaseList",buyers);
        return "admindashboard";
    }

    @PostMapping("/manageuser")
    public String manageUser(@RequestParam("user_id") String userId,@RequestParam("btn") String btn,Model model){
        if("Delete".equalsIgnoreCase(btn)){userRepository.deleteById(userId);return viewCustomer(model);}
        model.addAttribute("usermaster",userRepository.findById(userId).map(List::of).orElse(List.of()));return "editcustomer";
    }

    @PostMapping("/updateuser")
    public String updateUser(@RequestParam("user_id") String userId,@RequestParam("name") String name,
                             @RequestParam("role") String role,@RequestParam("status") String status,Model model){
        userRepository.findById(userId).ifPresent(u->{u.setName(name);u.setRole(role);u.setStatus(Integer.valueOf(status));userRepository.save(u);});
        return viewCustomer(model);
    }

    @GetMapping("/viewcustomer")
    public String viewCustomer(Model model){model.addAttribute("usermaster",userRepository.findByRole("customer"));return "viewcustomer";}

    @GetMapping("/viewstaff")
    public String viewStaff(Model model){model.addAttribute("usermaster",userRepository.findByRole("staff"));return "viewstaff";}

    @PostMapping("/managestaff")
    public String manageStaff(@RequestParam("user_id") String userId,@RequestParam("btn") String btn,Model model){
        if("Delete".equalsIgnoreCase(btn)){userRepository.deleteById(userId);return viewStaff(model);}
        model.addAttribute("usermaster",userRepository.findById(userId).map(List::of).orElse(List.of()));return "editstaff";
    }

    @PostMapping("/updatestaff")
    public String updateStaff(@RequestParam("user_id") String userId,@RequestParam("name") String name,
                              @RequestParam("role") String role,@RequestParam("status") String status,Model model){
        userRepository.findById(userId).ifPresent(u->{u.setName(name);u.setRole(role);u.setStatus(Integer.valueOf(status));userRepository.save(u);});
        return viewStaff(model);
    }

    @GetMapping("/viewcontact")
    public String viewContact(Model model){model.addAttribute("usermaster",contactRepository.findAll());return "viewcontact";}

    @GetMapping("/showfaq")
    public String showFaq(Model model){model.addAttribute("faqlist",faqRepository.findAll());return "showfaq";}

    @GetMapping("/addfaq") public String addFaq(){return "addfaq";}

    @PostMapping("/addfaq")
    public String addFaq(@RequestParam(value="question",required=false) String question,
                         @RequestParam(value="answer",required=false) String answer,
                         @RequestParam(value="btn",required=false) String btn,Model model){
        if(question!=null && answer!=null){faqRepository.save(new Faq(question,answer));}
        return "redirect:/showfaq";
    }

    @PostMapping("/updatefaq")
    public String updateFaq(@RequestParam("question") String question,@RequestParam("answer") String answer,
                            @RequestParam(value="sl_no",required=false) Integer id,Model model){
        Faq faq=(id==null?new Faq():faqRepository.findById(id).orElse(new Faq()));
        faq.setQuestion(question);faq.setAnswer(answer);faqRepository.save(faq);
        return "redirect:/showfaq";
    }

    @PostMapping({"/deletefaq","/dltfaq"})
    public String deleteFaq(@RequestParam("sl_no") Integer id){faqRepository.deleteById(id);return "redirect:/showfaq";}

    @GetMapping("/shop")
    public String getProducts(Model model){model.addAttribute("products",productRepository.findAll());return "shop";}

    @PostMapping("/updateprod")
    public String updateProduct(@RequestParam("prodid") Integer prodid,@RequestParam("prodname") String name,
                                @RequestParam("description") String description,@RequestParam("prodrate") Integer rate,
                                @RequestParam("prodqty") Integer qty,@RequestParam(value="prodimg",required=false) MultipartFile img,
                                Model model){
        productRepository.findById(prodid).ifPresent(p->{p.setProdname(name);p.setDescription(description);p.setProdrate(rate);p.setProdqty(qty);
            if(img!=null&&!img.isEmpty())try{p.setProd_img(img.getBytes());}catch(IOException ignored){}
            productRepository.save(p);});
        return allProd(model);
    }

    @PostMapping("/dltprod")
    public String deleteProduct(@RequestParam("prodid") Integer prodid,@RequestParam(value="btn",required=false) String btn,Model model){
        productRepository.deleteById(prodid);return allProd(model);
    }

    @GetMapping("/addproduct") public String product(){return "addproduct";}

    @GetMapping("/allproduct")
    public String allProd(Model model){model.addAttribute("prodmaster",productRepository.findAll());return "allproduct";}

    @PostMapping("/addorder")
    public String saveProduct(@RequestParam("prodid") Integer prodid,@RequestParam("prodname") String name,
                              @RequestParam("description") String description,@RequestParam("prodrate") Integer rate,
                              @RequestParam("prodqty") Integer qty,@RequestParam("photo") MultipartFile photo,Model model){
        try{
            Product p=new Product();p.setProdid(prodid);p.setProdname(name);p.setDescription(description);p.setProdrate(rate);p.setProdqty(qty);p.setProd_img(photo.getBytes());
            productRepository.save(p);model.addAttribute("sms","Product Added Successfully");
        }catch(IOException e){model.addAttribute("sms","Unable to read product image.");}
        return "addproduct";
    }

    @GetMapping("/vieworder")
    public String orders(Model model){model.addAttribute("vieworder",orderRepository.findAll());return "vieworder";}

    @PostMapping("/manageorder")
    public String manageOrder(@RequestParam("order_id") Integer orderId,@RequestParam("btn") String action){
        orderRepository.findById(orderId).ifPresent(o->{o.setStatus("Approve".equalsIgnoreCase(action)?"Approved":"Rejected");orderRepository.save(o);});
        return "redirect:/vieworder";
    }

    @PostMapping("/updatedelivery")
    public String updateDeliveryStatus(@RequestParam("order_id") Integer orderId,@RequestParam("delivery_status") String deliveryStatus){
        Optional<Order> op=orderRepository.findById(orderId);
        if(op.isEmpty())return "redirect:/vieworder";
        Order order=op.get();order.setDeliveryStatus(deliveryStatus);orderRepository.save(order);
        if("Delivered".equalsIgnoreCase(deliveryStatus)) generateBillAndEmail(order);
        return "redirect:/vieworder";
    }

    private void generateBillAndEmail(Order order){
        try{
            List<OrderItem> items=orderItemRepository.findByOrderId(order.getOrderId());
            if(items.isEmpty()) items=buildLegacyItems(order);
            User customer=userRepository.findById(order.getUserId()).orElse(null);

            File dir=new File(System.getProperty("user.dir")+"/bills");if(!dir.exists())dir.mkdirs();
            File bill=new File(dir,"Invoice_Order_"+order.getOrderId()+".pdf");
            Document doc=new Document(PageSize.A4,36,36,36,36);
            PdfWriter.getInstance(doc,new FileOutputStream(bill));doc.open();

            Font title=FontFactory.getFont(FontFactory.HELVETICA_BOLD,20,BaseColor.DARK_GRAY);
            Paragraph heading=new Paragraph("STEEL EMPORIUM - ORDER INVOICE",title);heading.setAlignment(Element.ALIGN_CENTER);doc.add(heading);
            doc.add(new Paragraph("Generated: "+LocalDateTime.now()));doc.add(new Paragraph(" "));
            PdfPTable info=new PdfPTable(2);info.setWidthPercentage(100);
            addCell(info,"Order ID",String.valueOf(order.getOrderId())); addCell(info,"Customer",customer!=null?customer.getName():"N/A");
            addCell(info,"Email/User ID",order.getUserId()); addCell(info,"Order Date",String.valueOf(order.getCreatedAt()));
            addCell(info,"Order Status",order.getStatus()); addCell(info,"Delivery Status",order.getDeliveryStatus());
            doc.add(info);doc.add(new Paragraph(" "));

            for(OrderItem item:items){
                if(item.getProductImage()!=null&&item.getProductImage().length>0){
                    try{Image image=Image.getInstance(item.getProductImage());image.scaleToFit(140,140);image.setAlignment(Element.ALIGN_CENTER);doc.add(image);}catch(Exception ignored){}
                }
                PdfPTable t=new PdfPTable(2);t.setWidthPercentage(100);
                addCell(t,"Product ID",String.valueOf(item.getProductId())); addCell(t,"Product Name",item.getProductName());
                addCell(t,"Description",item.getDescription()); addCell(t,"Rate","₹"+item.getRate());
                addCell(t,"Quantity",String.valueOf(item.getQuantity())); addCell(t,"Subtotal","₹"+item.getSubtotal());
                doc.add(t);doc.add(new Paragraph(" "));
            }
            PdfPTable total=new PdfPTable(2);total.setWidthPercentage(60);total.setHorizontalAlignment(Element.ALIGN_RIGHT);
            addCell(total,"TOTAL AMOUNT","₹"+order.getPrice());doc.add(total);
            doc.add(new Paragraph("Thank you for purchasing from Steel Emporium."));
            doc.close();

            order.setBillPath("/bills/Invoice_Order_"+order.getOrderId()+".pdf");orderRepository.save(order);

            if(customer!=null){
                MimeMessage mime=mailSender.createMimeMessage();
                MimeMessageHelper helper=new MimeMessageHelper(mime,true);
                helper.setTo(customer.getUserId());helper.setSubject("Steel Emporium - Order #"+order.getOrderId()+" Delivered");
                helper.setText("Dear "+customer.getName()+",\n\nYour order has been delivered successfully. Your invoice is attached.\n\nTotal: ₹"+order.getPrice()+"\nOrder ID: "+order.getOrderId()+"\n\nRegards,\nSteel Emporium Team");
                helper.addAttachment(bill.getName(),new FileSystemResource(bill));
                mailSender.send(mime);
            }
        }catch(Exception e){e.printStackTrace();}
    }

    private List<OrderItem> buildLegacyItems(Order order){
        List<OrderItem> result=new ArrayList<>();
        String[] ids=order.getProducts()==null?new String[0]:order.getProducts().split(",");
        String[] names=order.getProductsname()==null?new String[0]:order.getProductsname().split(",");
        for(int i=0;i<ids.length;i++){
            try{
                Integer id=Integer.valueOf(ids[i].trim());Product p=productRepository.findById(id).orElse(null);if(p==null)continue;
                result.add(new OrderItem(order.getOrderId(),id,i<names.length?names[i]:p.getProdname(),p.getDescription(),p.getProdrate(),1,p.getProd_img()));
            }catch(Exception ignored){}
        }
        return result;
    }

    private void addCell(PdfPTable table,String key,String value){
        table.addCell(new Phrase(key,FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
        table.addCell(value==null?"":value);
    }

    @GetMapping("/bill/{orderId}")
    @ResponseBody
    public ResponseEntity<byte[]> viewBill(@PathVariable Integer orderId)throws IOException{
        File f=new File(System.getProperty("user.dir")+"/bills/Invoice_Order_"+orderId+".pdf");
        if(!f.exists())return ResponseEntity.notFound().build();
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).body(java.nio.file.Files.readAllBytes(f.toPath()));
    }
}
