package com.example.steel_crafters;

import com.example.steel_crafters.entity.Faq;
import com.example.steel_crafters.repository.FaqRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.List;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner seedFaq(FaqRepository repo){
        return args -> {
            if(repo.count()==0){
                repo.saveAll(List.of(
                    new Faq("What products are available at Steel Emporium?","Steel Emporium provides furniture and steel-related products with product description, price, stock quantity and product image."),
                    new Faq("How can I register?","Open Sign Up, enter your name, email and password, then submit the form. Your account is stored using JPA Repository."),
                    new Faq("How can I login?","Use your registered email and password. After successful login, the project shows a success popup and opens the appropriate area based on your role."),
                    new Faq("How do I add a product to cart?","Login as a customer, open the shop and use the product Add to Cart option. The cart is stored for the logged-in user."),
                    new Faq("How is product stock handled?","Stock is checked before adding or increasing quantity. After an order is saved, the purchased quantity is deducted from product stock."),
                    new Faq("How does payment verification work?","The project validates the saved card details, checks balance and then sends an OTP to the registered email before the order is submitted."),
                    new Faq("What happens after an order is placed?","The order is stored with customer, product, quantity and total details. Admin can approve/cancel the order and update delivery status."),
                    new Faq("How is the invoice generated?","When admin marks an order as Delivered, the system generates a PDF invoice containing customer, order, product, quantity, price, description and the correct product image."),
                    new Faq("Can I view my previous orders?","Yes. After login, open My Order to see orders belonging to the current account."),
                    new Faq("How can I contact Steel Emporium?","Use the Contact page to submit your message. The message is stored in the contact table using JPA."),
                    new Faq("Can admin manage FAQs and products?","Yes. Admin can add/update/delete products and add/update/delete FAQ records through CRUD operations.")
                ));
            }
        };
    }
}
