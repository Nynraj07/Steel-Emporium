package com.example.steel_crafters.repository;
import com.example.steel_crafters.entity.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile,Integer>{
    Optional<UserProfile> findByUserId(String userId);
}
