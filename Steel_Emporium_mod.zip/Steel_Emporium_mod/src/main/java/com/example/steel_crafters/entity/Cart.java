package com.example.steel_crafters.entity;

import jakarta.persistence.*;
import java.util.Base64;

@Entity
@Table(name="cart")
public class Cart {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="sl_no") private Integer slNo;
    @Column(name="user_id",nullable=false,length=50) private String userId;
    @Column(nullable=false) private Integer prodid;
    @Column(nullable=false,length=50) private String prodname;
    @Column(nullable=false) private Integer qty;

    @Transient private Product product;
    @Transient private Integer total;

    public Cart(){}
    public Integer getSl_no(){return slNo;} public void setSl_no(Integer v){slNo=v;}
    public Integer getSlNo(){return slNo;} public void setSlNo(Integer v){slNo=v;}
    public String getUser_id(){return userId;} public void setUser_id(String v){userId=v;}
    public String getUserId(){return userId;} public void setUserId(String v){userId=v;}
    public Integer getProdid(){return prodid;} public void setProdid(Integer v){prodid=v;}
    public String getProdname(){return prodname;} public void setProdname(String v){prodname=v;}
    public Integer getQty(){return qty;} public void setQty(Integer v){qty=v;}
    public Product getProduct(){return product;} public void setProduct(Product v){product=v;}
    public Integer getProdrate(){return product!=null?product.getProdrate():0;}
    public byte[] getProd_img(){return product!=null?product.getProd_img():null;}
    public String getDescription(){return product!=null?product.getDescription():null;}
    public String getImageBase64(){byte[] image=getProd_img(); return image==null ? "" : Base64.getEncoder().encodeToString(image);}
    public Integer getTotal(){return total!=null?total:qty*getProdrate();}
    public void setTotal(Integer v){total=v;}
}
