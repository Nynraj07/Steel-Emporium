package com.example.steel_crafters.repository;

import com.example.steel_crafters.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

    List<Cart> findByUserId(String userId);

    Optional<Cart> findBySlNoAndUserId(Integer slNo, String userId);

    @Modifying
    @Transactional
    void deleteByUserId(String userId);
}