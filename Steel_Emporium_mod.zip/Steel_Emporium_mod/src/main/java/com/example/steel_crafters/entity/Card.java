package com.example.steel_crafters.entity;

import jakarta.persistence.*;

@Entity
@Table(name="card")
public class Card {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Integer id;
    @Column(name="account_number",unique=true,nullable=false) private String accountNumber;
    private String cvv; @Column(name="expiry_date") private String expiryDate; private Double amount;
    public Integer getId(){return id;} public String getAccountNumber(){return accountNumber;} public void setAccountNumber(String v){accountNumber=v;}
    public String getCvv(){return cvv;} public void setCvv(String v){cvv=v;} public String getExpiryDate(){return expiryDate;} public void setExpiryDate(String v){expiryDate=v;}
    public Double getAmount(){return amount;} public void setAmount(Double v){amount=v;}
}
