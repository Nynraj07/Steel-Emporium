package com.example.steel_crafters.entity;

import jakarta.persistence.*;

@Entity
@Table(name="user_profile")
public class UserProfile {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) @Column(name="profile_id") private Integer profileId;
    @Column(name="user_id",nullable=false) private String userId;
    private String address; private Integer age; private String phone; private String gender; private String city; private String state; private String country; private String photo;
    public Integer getProfileId(){return profileId;} public String getUserId(){return userId;} public void setUserId(String v){userId=v;}
    public String getAddress(){return address;} public void setAddress(String v){address=v;} public Integer getAge(){return age;} public void setAge(Integer v){age=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;} public String getGender(){return gender;} public void setGender(String v){gender=v;}
    public String getCity(){return city;} public void setCity(String v){city=v;} public String getState(){return state;} public void setState(String v){state=v;}
    public String getCountry(){return country;} public void setCountry(String v){country=v;} public String getPhoto(){return photo;} public void setPhoto(String v){photo=v;}
}
