package com.example.steel_crafters.repository;
import com.example.steel_crafters.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public interface OrderRepository extends JpaRepository<Order,Integer>{
    List<Order> findByUserIdOrderByOrderIdDesc(String userId);
    List<Order> findTop5ByOrderByOrderIdDesc();
    long countByStatus(String status);
    long countByDeliveryStatus(String status);
}
