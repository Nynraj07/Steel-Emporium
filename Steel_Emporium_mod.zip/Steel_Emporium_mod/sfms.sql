CREATE DATABASE IF NOT EXISTS furniture;

USE furniture;

-- =====================================================
-- 1. CARD TABLE
-- =====================================================

-- CREATE TABLE `card` (
--     `id` int(11) NOT NULL AUTO_INCREMENT,
--     `account_number` varchar(20) NOT NULL,
--     `cvv` varchar(4) NOT NULL,
--     `expiry_date` varchar(20) NOT NULL,
--     `amount` decimal(10,2) NOT NULL,

--     PRIMARY KEY (`id`),
--     UNIQUE KEY `account_number` (`account_number`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 2. CART TABLE
-- -- =====================================================

-- CREATE TABLE `cart` (
--     `sl_no` int(11) NOT NULL AUTO_INCREMENT,
--     `user_id` varchar(50) NOT NULL,
--     `prodid` int(11) NOT NULL,
--     `prodname` varchar(50) NOT NULL,
--     `qty` int(11) NOT NULL,

--     PRIMARY KEY (`sl_no`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 3. CONTACT TABLE
-- -- =====================================================

-- CREATE TABLE `contact` (
--     `sl_no` int(30) NOT NULL AUTO_INCREMENT,
--     `fname` varchar(50) NOT NULL,
--     `lname` varchar(50) NOT NULL,
--     `email` varchar(50) NOT NULL,
--     `msg` varchar(400) NOT NULL,

--     PRIMARY KEY (`sl_no`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 4. FAQ TABLE
-- -- =====================================================

-- CREATE TABLE `faq` (
--     `sl_no` int(50) NOT NULL AUTO_INCREMENT,
--     `question` varchar(500) NOT NULL,
--     `answer` varchar(1000) NOT NULL,

--     PRIMARY KEY (`sl_no`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 5. PRODUCT MASTER TABLE
-- -- =====================================================

-- CREATE TABLE `product_master` (
--     `prodid` int(11) NOT NULL,
--     `prodname` varchar(50) NOT NULL,
--     `description` varchar(800) NOT NULL,
--     `prodrate` int(11) NOT NULL,
--     `prodqty` int(11) NOT NULL,
--     `prod_img` longblob NOT NULL,

--     PRIMARY KEY (`prodid`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 6. SAVE ORDER TABLE
-- -- =====================================================

-- CREATE TABLE `save_order` (
--     `order_id` int(11) NOT NULL AUTO_INCREMENT,
--     `user_id` varchar(50) NOT NULL,
--     `price` int(50) NOT NULL,
--     `order_status` int(11) NOT NULL DEFAULT 1,
--     `products` varchar(200) NOT NULL,
--     `productsname` varchar(500) NOT NULL,
--     `status` varchar(11) NOT NULL DEFAULT 'pending',
--     `delivery_status` varchar(40) NOT NULL DEFAULT 'Not Delivered',

--     PRIMARY KEY (`order_id`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 7. STUDENT TABLE
-- -- =====================================================

-- CREATE TABLE `student` (
--     `id` int(11) NOT NULL,
--     `email` varchar(255) DEFAULT NULL,
--     `name` varchar(255) DEFAULT NULL,

--     PRIMARY KEY (`id`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 8. USER MASTER TABLE
-- -- =====================================================

-- CREATE TABLE `user_master` (
--     `name` varchar(50) NOT NULL,
--     `user_id` varchar(50) NOT NULL,
--     `password` varchar(100) NOT NULL,
--     `role` varchar(40) NOT NULL,
--     `status` int(11) NOT NULL DEFAULT 0,

--     PRIMARY KEY (`user_id`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- -- =====================================================
-- -- 9. USER PROFILE TABLE
-- -- =====================================================

-- CREATE TABLE `user_profile` (
--     `profile_id` int(11) NOT NULL AUTO_INCREMENT,
--     `user_id` varchar(50) NOT NULL,
--     `address` varchar(255) DEFAULT NULL,
--     `age` int(11) DEFAULT NULL,
--     `phone` varchar(20) DEFAULT NULL,
--     `gender` varchar(10) DEFAULT NULL,
--     `city` varchar(50) DEFAULT NULL,
--     `state` varchar(50) DEFAULT NULL,
--     `country` varchar(50) DEFAULT NULL,
--     `photo` varchar(255) DEFAULT NULL,

--     PRIMARY KEY (`profile_id`),
--     KEY `fk_user` (`user_id`),

--     CONSTRAINT `fk_user`
--         FOREIGN KEY (`user_id`)
--         REFERENCES `user_master` (`user_id`)
-- ) ENGINE=InnoDB
-- DEFAULT CHARSET=utf8mb4
-- COLLATE=utf8mb4_general_ci;


-- =====================================================
-- DATABASE CREATED SUCCESSFULLY
-- NO DATA INSERTED
-- =====================================================